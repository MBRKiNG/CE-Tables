__  __  ____  _____  _  ___ _   _  ____ 
 |  \/  || __ )|  _ \ | |/ /_| \ | |/ ___|
 | |\/| ||  _ \| |_) || ' / | ||  \| | |  _ 
 | |  | || |_) |  _ < | . \ | || |\  | |_| |
 |_|  |_||____/|_| \_\|_|\_\|_||_| \_|\____|
                                            
      ~ Mina The Hollower Patcher ~

===============================================================================
                             - RELEASE INFO -
===============================================================================

 Game        : Mina The Hollower
 Author      : MBRKiNG
 Type        : Executable Patcher (.exe)

===============================================================================
                          - WHAT DOES THIS DO? -
===============================================================================

 This patch permanently modifies the game executable to apply the features 
 from the original Cheat Engine table without needing CE running in the 
 background:

 * Achievements (feats) are not disabled when using cheats.
 * The annoying "cheater flag" is completely removed from your savegame.
 * Allows you to earn achievements even when using the in-game cheat menu.

 You no longer need to enable scripts manually in the Main Menu before 
 loading your save. Just patch it once and you are good to go!

===============================================================================
                             - INSTRUCTIONS -
===============================================================================

 1. Run the MinaTheHollowerPatcher.exe
 2. A file dialog will open. Select your game executable 
    (MinaTheHollower.exe).
 3. The patcher will automatically:
    - Display your Current Game Version.
    - Create a safe backup of your original file (.bak).
    - Scan the AOB signatures and apply the patches.
 4. Close the patcher and start the game. Have fun!

===============================================================================
                           - LINKS & UPDATES -
===============================================================================

 -> https://opencheattables.com
 -> https://github.com/mbrking/CE-Tables

===============================================================================